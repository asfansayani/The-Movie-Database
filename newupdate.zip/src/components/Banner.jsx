import { Container, Row, Col } from 'react-bootstrap'
export default function Banner() {
    return (
        <>
            <Container>
                <div className='banner'>
                    <Row>
                        <Col>
                            <h1 className='mb-0'><b>Welcome.</b></h1>
                            <p className='fw-semibold mb-5'>Millions of movies, TV shows and people to discover. Explore now.</p>
                            <form action='search' className='d-flex inputWrap'>
                                <input type="search" placeholder='Search for a movie, tv show, person......' />
                                <input type="submit" value="search" />
                            </form>
                        </Col>
                    </Row>
                </div>
            </Container>

        </>
    )
}
