import React from "react"
export default function SecHd({sechd}) {
  return (
    <h2 className="sechd fs-4 mb-0">{sechd}</h2>
  )
}
