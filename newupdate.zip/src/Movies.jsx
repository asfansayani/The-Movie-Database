import MediaCard from "./components/MediaCard";
import moviesdata from "./data.json";
import { Container, Row, Col, Button } from "react-bootstrap";
import { useState } from "react";

const Movies = () => {
  const { trending, popular , free} = moviesdata;
  const [data, setData] = useState(trending);
  const [text, setText] = useState('Show More');
  const [loadState, setLoadState] = useState('trending');
  const handleData = () => {
    if (loadState === 'trending') {
      setData(prevData => [...prevData, ...popular]);
      setLoadState('popular'); 
    } else if (loadState === 'popular') {
      setData(prevData => [...prevData, ...free]);
      setLoadState('free');
      setText('Show Less');
    }
  };

  return (
    <>
      <section className="sec-pad">
        <Container>
          <Row>
            {data.map((item, index) => (
              <Col lg={2} key={index}>
                <MediaCard
                  img={item.img}
                  name={item.name}
                  date={item.date}
                  percent={item.percent}
                />
              </Col>
            ))}
            <Col>
              <Button 
                onClick={handleData} 
                variant="primary" 
                className="w-100 fs-4 fw-bold"
              >
                {text}
              </Button>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default Movies;